/* Shared Grama Seva navigation translations (English, Kannada, Hindi). */
(() => {
  const words = {
  "en": {
    "services": "Services",
    "navSchemes": "Government Schemes",
    "navUpdates": "Latest Updates",
    "navReport": "Report a Problem",
    "navSanitation": "Sanitation Information",
    "home": "Home",
    "schemes": "Schemes",
    "how": "How It Works",
    "about": "About",
    "survey": "Village Survey",
    "problems": "Problems",
    "objectives": "Objectives",
    "solutions": "Solutions",
    "faq": "FAQ",
    "report": "Report Problem",
    "notifications": "Notifications",
    "enable": "Enable browser alerts",
    "openNotifications": "Open notifications"
  },
  "kn": {
    "services": "ಸೇವೆಗಳು",
    "navSchemes": "ಸರ್ಕಾರಿ ಯೋಜನೆಗಳು",
    "navUpdates": "ಇತ್ತೀಚಿನ ಮಾಹಿತಿ",
    "navReport": "ಸಮಸ್ಯೆಯನ್ನು ವರದಿ ಮಾಡಿ",
    "navSanitation": "ನೈರ್ಮಲ್ಯ ಮಾಹಿತಿ",
    "home": "ಮುಖಪುಟ",
    "schemes": "ಯೋಜನೆಗಳು",
    "how": "ಇದು ಹೇಗೆ ಕಾರ್ಯನಿರ್ವಹಿಸುತ್ತದೆ",
    "about": "ನಮ್ಮ ಬಗ್ಗೆ",
    "survey": "ಗ್ರಾಮ ಸಮೀಕ್ಷೆ",
    "problems": "ಸಮಸ್ಯೆಗಳು",
    "objectives": "ಉದ್ದೇಶಗಳು",
    "solutions": "ಪರಿಹಾರಗಳು",
    "faq": "ಸಾಮಾನ್ಯ ಪ್ರಶ್ನೆಗಳು",
    "report": "ಸಮಸ್ಯೆ ವರದಿ",
    "notifications": "ಅಧಿಸೂಚನೆಗಳು",
    "enable": "ಬ್ರೌಸರ್ ಎಚ್ಚರಿಕೆಗಳನ್ನು ಸಕ್ರಿಯಗೊಳಿಸಿ",
    "openNotifications": "ಅಧಿಸೂಚನೆಗಳನ್ನು ತೆರೆಯಿರಿ"
  },
  "hi": {
    "services": "सेवाएँ",
    "navSchemes": "सरकारी योजनाएँ",
    "navUpdates": "नवीनतम अपडेट",
    "navReport": "समस्या की रिपोर्ट करें",
    "navSanitation": "स्वच्छता संबंधी जानकारी",
    "home": "होम",
    "schemes": "योजनाएँ",
    "how": "यह कैसे काम करता है",
    "about": "हमारे बारे में",
    "survey": "ग्राम सर्वेक्षण",
    "problems": "समस्याएँ",
    "objectives": "उद्देश्य",
    "solutions": "समाधान",
    "faq": "सामान्य प्रश्न",
    "report": "समस्या रिपोर्ट करें",
    "notifications": "सूचनाएँ",
    "enable": "ब्राउज़र अलर्ट सक्षम करें",
    "openNotifications": "सूचनाएँ खोलें"
  }
};
  const selector = document.getElementById('language') || document.getElementById('languageSelect');
  function applyNavigationLanguage(lang) {
    const t = words[lang] || words.en;
    document.querySelectorAll('[data-i18n]').forEach(el => {
      const key = el.getAttribute('data-i18n');
      if (t[key]) el.textContent = t[key];
    });
    document.querySelectorAll('[data-i18n-aria]').forEach(el => {
      const key = el.getAttribute('data-i18n-aria');
      if (t[key]) el.setAttribute('aria-label', t[key]);
    });
    document.documentElement.lang = lang;
  }
  if (selector) {
    applyNavigationLanguage(selector.value || 'en');
    selector.addEventListener('change', () => applyNavigationLanguage(selector.value));
  }
  // Also support pages that may expose both selectors during future edits.
  document.querySelectorAll('#language, #languageSelect').forEach(el => {
    if (el !== selector) el.addEventListener('change', () => applyNavigationLanguage(el.value));
  });
})();
